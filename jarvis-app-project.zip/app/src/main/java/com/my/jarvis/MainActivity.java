package com.my.jarvis;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Simple screen with three permission buttons and a start button. */
public class MainActivity extends Activity {

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 64, 48, 48);
        root.setBackgroundColor(Color.parseColor("#06101f"));

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S.");
        title.setTextColor(Color.parseColor("#44e0ff"));
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Grant these three, then press Start. You can turn any off later.");
        sub.setTextColor(Color.parseColor("#9fc7e0"));
        sub.setPadding(0, 16, 0, 32);
        root.addView(sub);

        root.addView(btn("1. Allow floating over apps", v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            else toast("Already allowed.");
        }));

        root.addView(btn("2. Allow control of apps (Accessibility)", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        root.addView(btn("3. Allow notifications", v -> {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        }));

        Button start = btn("START JARVIS", v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                toast("Please allow floating over apps first (button 1).");
                return;
            }
            Intent s = new Intent(this, BubbleService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(s);
            else startService(s);
            toast("JARVIS is on your screen. You can leave this app.");
            moveTaskToBack(true);
        });
        start.setBackgroundColor(Color.parseColor("#0066ff"));
        root.addView(start);

        TextView note = new TextView(this);
        note.setText("\nFor button 2 on Android 13+: open the app's info page, tap the 3-dot menu, choose \"Allow restricted settings\", then enable JARVIS under Accessibility.\n\nEverything runs on your phone. No account, no internet needed. Tap the glowing orb any time to speak.");
        note.setTextColor(Color.parseColor("#6f93ac"));
        note.setPadding(0, 32, 0, 0);
        root.addView(note);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#06101f"));
        sv.addView(root);
        setContentView(sv);
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#13263d"));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 10, 0, 10);
        b.setLayoutParams(p);
        b.setOnClickListener(l);
        return b;
    }

    private void toast(String s) {
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_LONG).show();
    }
}
